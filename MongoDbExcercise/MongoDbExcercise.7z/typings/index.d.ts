/// <reference path="globals/mongodb/index.d.ts" />
/// <reference path="globals/mongoose/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
